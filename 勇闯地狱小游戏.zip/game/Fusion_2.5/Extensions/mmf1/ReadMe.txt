Copy into this folder all the MMF1 extensions that are not converted for MMF2. 

MMF2 will be able to load your MMF1 applications that use those extensions
so you can edit and replace the concerned events.

MMF2 won't be able to run your application until you have removed or
replaced all those events.

Note: if you need to load TGF1 or C&C applications that use extensions that
are not converted to MMF2, you have to copy into this folder the MMF1 version
of these extensions.

